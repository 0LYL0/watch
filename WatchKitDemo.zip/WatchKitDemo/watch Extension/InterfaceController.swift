//
//  InterfaceController.swift
//  watch Extension
//
//  Created by 刘雅兰 on 2017/9/9.
//  Copyright © 2017年 刘雅兰. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
    
    @IBOutlet var guessSlider:WKInterfaceSlider!
    @IBOutlet var guessLabel:WKInterfaceLabel!
    @IBOutlet var resultLabel:WKInterfaceLabel!
    
    var guessNumber = 3
    
    
    
    @IBAction func updateGuess(_ value: Float) {
        
        guessNumber=Int(value * 5)
        guessLabel.setText("Your guess:\(guessNumber)")
        
        
        
        
        
    }
    
    @IBAction func startGuess() {
        
        let randomNumber = Int(arc4random_uniform(6))
        
        if (guessNumber==randomNumber){
            resultLabel.setText("Correct.You win!")
        }else{
            resultLabel.setText("Wrong.The number is \(randomNumber)")
        }
        
        
    }

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
